<?php

//==================================display glasses function====================================

function displayvideoglasses(){
    $sql ="SELECT * FROM glasses_details WHERE video_frame='1' ORDER BY g_id DESC ";
    include ("../connection/conection.php");
    $qrun = mysqli_query($conn, $sql);
    $er =mysqli_errno($conn);
    //echo $er;
    if(mysqli_num_rows($qrun) >0 ){
        while ($data = mysqli_fetch_array($qrun)){

            ?>

            <div class="col-md-3">
                <div class="card h-100">
                    <img src="../glasses_admin/glasses_images/<?php  echo $data['g_pic1']; ?>" class="card-img-top" alt="...">
                    <div class="card-body">
                        <h5 class="card-title"><?php  echo $data['g_name']; ?> </h5>
                        <br>

                        <button class="btn btn-primary" onclick="JEELIZVTOWIDGET.load('<?php  echo $data['sku_number'] ?>')">Try Now</button>
                        <a href="../portfolio-details.php?single_display=<?php echo $data['g_id'] ?>" class="btn btn-primary">Buy Now</a>

                    </div>
                </div>
            </div>

            <?php


        }
    }


}

?>
