# Static glasses 3D models

These 3D models were exported from GLTF 3D models using Glasses 3D studio.

[More information here](https://github.com/jeeliz/jeelizGlassesVTOWidget#as-a-static-file)

